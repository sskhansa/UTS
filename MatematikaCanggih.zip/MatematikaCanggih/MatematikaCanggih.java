/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MatematikaCanggih;

/**
 *
 * @author shafa
 */
public class MatematikaCanggih {
    int tambah;
    int kali;
    int modulus;
    void pertambahan(int a, int b){
        tambah = a +  b;
        System.out.println("a + b = "+tambah);
    }
    int getTambah(){
        return tambah;
    }
    void perkalian(int a, int b){
        kali = a * b;
        System.out.println("a * b = "+ kali);
    }
    int getKali(){
        return kali;
    }
    void modulus(int a, int b){
        modulus = a % b;
        System.out.println("a % b = "+modulus);
    }
    int getModulus(){
        return modulus;
    }
}
