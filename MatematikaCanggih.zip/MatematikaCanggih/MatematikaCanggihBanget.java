/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MatematikaCanggih;

/**
 *
 * @author shafa
 */
public class MatematikaCanggihBanget extends MatematikaCanggih {
    int tambahEmpat;
    void pertambahanEmpat(int a, int b, int c, int d){
        tambahEmpat = a+b+c+d;
        System.out.println("a + b + c + d = "+ tambahEmpat);
    }
    int getTambahEmpat(){
        return tambahEmpat;
    }
}
