/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Person;

import orang.orang;

/**
 *
 * @author shafa
 */
public class PersonBeraksi {
    public static void main(String[] args) {
        Person person1 = new Person();
        person1.name = "Joe Smith";
        person1.age = 24;
        person1.printBiodata();
                
        Person person2 = new Person();
        person2.name = "Mary Sharp";
        person2.age = 52;
        person2.printBiodata();
    }
}
