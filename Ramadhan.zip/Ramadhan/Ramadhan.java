/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ramadhan;

/**
 *
 * @author shafa
 */
public class Ramadhan {
    void Puasa(){
        System.out.println("Selamat menunaikan ibadah puasa!");
    }
    void Sahur(){
        System.out.println("Makanlah sebelum adzhan Subuh dikumandangkan");
    }
    void Berbuka(){
        System.out.println("Selamat berbuka! Mohon untuk makan berhati-hati");
    }
    void IdulFitri(){
        System.out.println("Minal Aidin Wal Faizin");
    }
}
