/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ramadhan;

/**
 *
 * @author shafa
 */
public class RamadhanBeraksi {
    public static void main(String[] args) {
        Ramadhan ramadhan2021 = new Ramadhan();
        ramadhan2021.Puasa();
        ramadhan2021.Sahur();
        ramadhan2021.Berbuka();
        ramadhan2021.IdulFitri();
    }
}
